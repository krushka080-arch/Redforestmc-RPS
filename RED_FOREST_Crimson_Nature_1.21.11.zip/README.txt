RED FOREST — Crimson Nature
Minecraft 1.21.11

Установка:
1. Не распаковывай ZIP.
2. Помести RED_FOREST_Crimson_Nature_1.21.11.zip в папку resourcepacks.
3. Minecraft → Настройки → Наборы ресурсов.
4. Включи ресурс-пак.

Примечание:
Пакет заменяет основные текстуры листвы на красные/бордовые.
